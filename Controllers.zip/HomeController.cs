﻿using Microsoft.AspNetCore.Mvc;
using CVMaker.Models;
using CVMaker.Infrastructure;
namespace CVMaker_Web.Controllers
{
	public class HomeController : Controller
	{
        private readonly string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;";
        
        public IActionResult Index(bool returnJson = false)
		{
            string cookieMessage = String.Empty;
            bool isFirstVisit = false;

            if (HttpContext.Request.Cookies.ContainsKey("acceptedCookies"))
            {
                string lastVisited = HttpContext.Request.Cookies["acceptedCookies"];
                isFirstVisit = false;
            }
            else
            {
                CookieOptions cookieOptions = new CookieOptions();
                cookieOptions.Expires = DateTime.Now.AddDays(7);
                HttpContext.Response.Cookies.Append("acceptedCookies", DateTime.Now.ToString());
                isFirstVisit = true;

            }
            GenericRepository<Template> gr = new GenericRepository<Template>(connectionString);
            List<Template> templates = gr.GetAll<Template>();
            if (returnJson)
            {
                return PartialView("_DisplayTemplates",templates);
            }
            else
            {
                //return Json(false);
                return View();
            }
        }

		
        public IActionResult Privacy()
        {
            HttpContext.Response.Cookies.Delete("first_visit");
            return View();
        }
        public IActionResult sample()
        {
            return View("sample");
        }

    }
  
}
