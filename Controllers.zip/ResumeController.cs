﻿using Microsoft.AspNetCore.Mvc;
using Project_Authentication.Models;
using CVMaker_Web.Controllers;
using CVMaker.Models;
using CVMaker.Infrastructure;
using Application.Interfaces;

namespace CVMaker_Web.Controllers
{
    public class ResumeController : Controller
    {
        private readonly IRepository<Template> _repository;
        private readonly string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;";

        private readonly IWebHostEnvironment _env;
        private readonly ILogger<AdminController> _logger;

        public ResumeController(IWebHostEnvironment env, ILogger<AdminController> logger)
        {
            _env = env;
            _logger = logger;
        }
        [HttpGet]
        public IActionResult AddResume()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddResume(IFormFile resume, string name)
        {
            Resume r = new Resume
            {
                UserId = TempData["ResumeId"].ToString(),
                Name = name
            };

            string wwwrootpath = _env.WebRootPath;
            string path = Path.Combine(wwwrootpath, "Resumes");


            if (resume != null && resume.Length > 0)
            {
                string filepath = Path.Combine(path, resume.FileName);
                r.resume = Path.Combine("Resumes", resume.FileName);
                using (var FileStream = new FileStream(filepath, FileMode.Create))
                {
                    resume.CopyTo(FileStream);
                }
            }

            GenericRepository<Resume> repository = new GenericRepository<Resume>("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;");
            repository.Add(r);
            return Json(true);
        }

        public IActionResult DeleteResumes(int id)
        {
            GenericRepository<Resume> repository = new GenericRepository<Resume>("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;");
            repository.DeleteById(id);
            return Json(true);
        }
    }
}
