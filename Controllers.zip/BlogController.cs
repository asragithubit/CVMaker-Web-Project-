﻿using Microsoft.AspNetCore.Mvc;
using CVMaker.Models;
using CVMaker.Infrastructure;
using Application.Interfaces;
using Application.Services;

namespace CVMaker_Web.Controllers
{
    public class BlogController : Controller
    {
        private readonly string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;";
        public IActionResult ResumeWritingService()
        {
            GenericRepository<WritingTemplates> repository = new GenericRepository<WritingTemplates>(connectionString);
            List<WritingTemplates> templates = repository.GetAll<WritingTemplates>();
            return View(templates);
        }

        public IActionResult BlogWriting()
        {
            return View("BlogWriting");
        }

        public IActionResult Contact()
        {
            return View("Contact");
        }

        public IActionResult hairStyle()
        {
            return View("hairStyle");
        }

        public IActionResult CarSales()
        {
            return View("CarSales");
        }

        public IActionResult Cosmotology()
        {
            return View("Cosmotology");
        }

        public IActionResult fastFoodManager()
        {
            return View("fastFoodManager");
        }

        public IActionResult eventCoordinator()
        {
            return View();
        }


        public IActionResult logisticsCoordinator()
        {
            return View();
        }

        public IActionResult hospitality()
        {
            return View();
        }

        public IActionResult executives()
        {
            return View();
        }

        public IActionResult Interests()
        {
            return View();
        }

        public IActionResult storeManager()
        {
            return View();
        }

        public IActionResult Sports()
        {
            return View();
        }

        public IActionResult contactForm()
        {
            return View();
        }

        public IActionResult cancelSubscription()
        {
            return View();
        }

        public IActionResult AboutUs()
        {
            return View();
        }

       public IActionResult Continue()
        {
            return View();
        }

        public IActionResult payment()
        {
            return View();
        }

        public IActionResult contactSend()
        {
            return View();
        }
        public IActionResult cancelSubscriptionSend()
        {
            return View();
        }

        public IActionResult FAQ()
        {
            return View();  
        }

        public IActionResult PrivacyAndCookie()
        {
            return View();
        }

        public IActionResult Terms()
        {
            return View();  
        }
    }
}
