﻿using Microsoft.AspNetCore.Mvc;
using Project_Authentication.Models;
using CVMaker_Web.Controllers;
using CVMaker.Models;
using CVMaker.Infrastructure;
using Application.Interfaces;

namespace CVMaker_Web.Controllers
{
    public class TemplateController : Controller
    {

        private readonly IRepository<Template> _repository;
        private readonly string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;";

        private readonly IWebHostEnvironment _env;
        private readonly ILogger<AdminController> _logger;

        public TemplateController(IWebHostEnvironment env, ILogger<AdminController> logger, IRepository<Template> repository)
        {
            _env = env;
            _logger = logger;
            _repository = repository;
            repository.setConnnectionString(connectionString);
        }


        [HttpGet]
        public IActionResult AddTemplate()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddTemplate(IFormFile resume)
        {

            try
            {
                string wwwrootpath = _env.WebRootPath;
                string path = Path.Combine(wwwrootpath, "templates");
                Template template = new Template
                {
                    UserId = TempData["UserId"].ToString()
                };

                if (resume != null && resume.Length > 0)
                {
                    string filepath = Path.Combine(path, resume.FileName);
                    template.Resume = Path.Combine("templates", resume.FileName);
                    using (var FileStream = new FileStream(filepath, FileMode.Create))
                    {
                        resume.CopyTo(FileStream);
                    }
                }

                //GenericRepository<Template> repository = new GenericRepository<Template>("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;");
                //repository.Add(template);
                _repository.Add(template);

                return View(true);
            }
            catch
            {
                return Json(false);
            }
        }

        [HttpPost]
        public IActionResult DeleteTemplate(int id)
        {
            //GenericRepository<Template> repository = new GenericRepository<Template>("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;");
            //repository.DeleteById(id);
            _repository.DeleteById(id);
            return Json(true);
        }
    }
}
