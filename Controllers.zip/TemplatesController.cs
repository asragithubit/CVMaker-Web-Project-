﻿using Microsoft.AspNetCore.Mvc;
using CVMaker.Models;
namespace CVMaker_Web.Controllers;
using CVMaker.Infrastructure;

public class TemplatesController : Controller
{
    private readonly string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;";

    public ViewResult CVTemplates()
    {
        GenericRepository<CVs> repository = new GenericRepository<CVs>(connectionString);
        List<CVs> cvs=repository.GetAll<CVs>();
        return View(cvs);
    }

    public IActionResult ResumeTemplates()
    {
        GenericRepository<Resume> repository = new GenericRepository<Resume>(connectionString);
        List<Resume> resumes = repository.GetAll<Resume>();
        return View(resumes);
        //return PartialView("_DisplayResumes", resumes);
    }
}
