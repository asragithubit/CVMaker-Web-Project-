﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using CVMaker.Models;
using System;
using System.Security.Policy;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Microsoft.AspNetCore.Http;
using System;
using System.Linq.Expressions;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Identity;
using Application.Services;
using CVMaker.Models;
using CVMaker.Infrastructure;


namespace CVMaker_Web.Controllers
{


    [Authorize]
    public class UserController : Controller
    {
        private readonly string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;";
        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _env;
        private static int id;
        private string filePath;
        private readonly UserDetailsService _userDetailsService;


        public UserController(ILogger<HomeController> logger, IWebHostEnvironment env,UserDetailsService userDetailsService)
        {
            _logger = logger;
            _env = env;
            _userDetailsService = userDetailsService;
        }

        [HttpGet]
      public IActionResult CreateResume()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CreateResume(UserDetails user, string skill, string levelOfSkill, string publicationDescription, string language, string levelOfLanguage, string jobTitle, string workCityTown, string workStartDate, string workEndDate, string workDescription, string employer,string hobby, string companyName, string phoneNumber, string email, string contactPerson, string degree, string school, string educationCityTown, string educationStartDate, string educationEndDate, string educationDescription, string course, string institution, string courseStartDate, string courseEndDate, string courseDescription, IFormFile profilePhoto)
        {

            if (ModelState.IsValid)
            {

                //Skills
                SkillsDetails _skill = new SkillsDetails
                {
                    Skills = skill,
                    LevelOfSkills = levelOfSkill
                };
                user.skills.Add(_skill);

                //Publication
                PublicationDetails _publication = new PublicationDetails
                {
                    Description = publicationDescription
                };

                user.publication = _publication;

                //Language
                LanguageDetails _language = new LanguageDetails
                {
                    Language = language,
                    LevelOfLanguage = levelOfLanguage
                };

                user.LanguageDetails.Add(_language);

                //WorkExperience
                WorkExperience experience = new WorkExperience
                {
                    JobTitle = jobTitle,
                    StartDate = workStartDate,
                    EndDate = workEndDate,
                    Description = workDescription,
                    Employer = employer,
                    WorkPlace = workCityTown
                };

                user.workExperiences.Add(experience);

                //Hobby
                Hobbies _hobby = new Hobbies
                {
                    Hobby = hobby
                };

                user.hobbies.Add(_hobby);

                //Company
                Reference reference = new Reference
                {
                    CompanyName = companyName,
                    ContactEmail = email,
                    ContactPhoneNumber = phoneNumber,
                    ContactPerson = contactPerson
                };

                user.reference.Add(reference);

                //Education
                EducationDetails education = new EducationDetails
                {
                    SchoolName = school,
                    Degree = degree,
                    StartDate = educationStartDate,
                    EndDate = educationEndDate,
                    CityTown = educationCityTown,
                    Description = educationDescription,
                };

                user.educationDetails.Add(education);

                //CourseDetails
                CourseDetails _course = new CourseDetails
                {
                    CourseName = course,
                    Institution = institution,
                    StartDate = courseStartDate,
                    EndDate = courseEndDate,
                    Description = courseDescription
                };

                string wwwrootpath = _env.WebRootPath;
                string path = Path.Combine(wwwrootpath, "UserImages");
                if (profilePhoto != null && profilePhoto.Length > 0)
                {
                    string filepath = Path.Combine(path, profilePhoto.FileName);
                    user.profilePhoto = Path.Combine("UserImages", profilePhoto.FileName);
                    using (var FileStream = new FileStream(filepath, FileMode.Create))
                    {
                        profilePhoto.CopyTo(FileStream);
                    }
                }
                user.Courses.Add(_course);


                            //Saving Data in Database

                //Saving Data in PersonalDetails Table
                _userDetailsService.AddPersonalDetails(user);
                //Retrieving Id to set other tables' Id 
                id = _userDetailsService.getId(user.CNIC);

                //Assigning id to other's tables Id attribute
                //<--------CourseDetails---------->
                foreach (var Course in user.Courses)
                {
                    Course.Id = id;
                }

                //<--------EducationDetails---------->
                foreach (var Education in user.educationDetails)
                {
                    Education.Id = id;
                }

                //<--------Hobbies---------->
                foreach (var Hobby in user.hobbies)
                {
                    Hobby.Id = id;
                }

                //<--------LanguageDetails---------->
                foreach (var Language in user.LanguageDetails)
                {
                    Language.Id = id;
                }

                //<--------PublicationDetails---------->
                user.publication.Id = id;

                //<--------References---------->
                foreach (var refer in user.reference)
                {
                    refer.Id = id;
                }


                //<--------Skills---------->
                foreach (var Skill in user.skills)
                {
                    Skill.Id = id;
                }


                //<--------WorkExperience---------->
                foreach (var Experience in user.workExperiences)
                {
                    Experience.Id = id;
                }

                //Now Adding rest of the tables' data in database
                _userDetailsService.AddOtherDetails(user);

                TempData["userDetails"] = JsonConvert.SerializeObject(user);
                return RedirectToAction("CVTemplate1", "User");
            }
            return View("CreateResume");
        }

        [HttpGet]
        public IActionResult getPersonalDetails()
        {
            return View();
        }

        public IActionResult PrivacyandCookie()
        {
            return View();
        }
        public IActionResult CVTemplate1()
        {
            
            string jsonString = TempData["userDetails"].ToString();
            UserDetails user = JsonConvert.DeserializeObject<UserDetails>(jsonString);
            TempData["userDetails"] = JsonConvert.SerializeObject(user);
            return View(user);
        }

        public IActionResult CVTemplate2()
        {
            string jsonString = TempData["userDetails"].ToString();
            UserDetails user = JsonConvert.DeserializeObject<UserDetails>(jsonString);
            TempData["userDetails"] = JsonConvert.SerializeObject(user);
            return View(user);
        }

        public IActionResult CVTemplate3()
        {
            string jsonString = TempData["userDetails"].ToString();
            UserDetails user = JsonConvert.DeserializeObject<UserDetails>(jsonString);
            TempData["userDetails"] = JsonConvert.SerializeObject(user);
            return View(user);
        }

        public IActionResult CVTemplate4()
        {
            string jsonString = TempData["userDetails"].ToString();
            UserDetails user = JsonConvert.DeserializeObject<UserDetails>(jsonString);
            TempData["userDetails"] = JsonConvert.SerializeObject(user);
            return View(user);
        }
        public IActionResult UpdateDetails(int id)
        {
            
            return View(id);
        }
    }
}
