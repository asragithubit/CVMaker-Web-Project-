﻿using Microsoft.AspNetCore.Mvc;
using Project_Authentication.Models;
using CVMaker_Web.Controllers;
using CVMaker.Models;
using CVMaker.Infrastructure;
using Application.Interfaces;

namespace CVMaker_Web.Controllers
{
    public class CVController : Controller
    {

        private readonly IRepository<Template> _repository;
        private readonly string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;";

        private readonly IWebHostEnvironment _env;
        private readonly ILogger<AdminController> _logger;

        public CVController(IWebHostEnvironment env, ILogger<AdminController> logger)
        {
            _env = env;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult AddCVs()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddCVs(IFormFile cv, string name)
        {
            CVs c = new CVs
            {
                UserId = TempData["CVId"].ToString(),
                Name = name
            };

            string wwwrootpath = _env.WebRootPath;
            string path = Path.Combine(wwwrootpath, "CV(s)");


            if (cv != null && cv.Length > 0)
            {
                string filepath = Path.Combine(path, cv.FileName);
                c.cv = Path.Combine("CV(s)", cv.FileName);
                using (var FileStream = new FileStream(filepath, FileMode.Create))
                {
                    cv.CopyTo(FileStream);
                }
            }

            GenericRepository<CVs> repository = new GenericRepository<CVs>("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;");
            repository.Add(c);
            return Json(true);
        }
        public IActionResult DeleteCV(int id)
        {
            GenericRepository<CVs> repository = new GenericRepository<CVs>(connectionString);
            repository.DeleteById(id);
            return RedirectToAction("CVTemplates", "Templates");
        }
    }
}
