﻿using Project_Authentication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CVMaker.Models;
using Application.Interfaces;

namespace Application.Services
{
    public class UserDetailsService
    {
        IUser _repository;
        public UserDetailsService(IUser repository)
        {
            _repository = repository;
        }

        public async Task AddPersonalDetails(UserDetails user)
        {
            _repository.AddPersonalDetails(user);
        }

        public async Task AddOtherDetails(UserDetails user)
        {
            _repository.AddOtherDetails(user);
        }

        public async Task<int> getId(string cnic)
        {
            return await _repository.getId(cnic);
        }

    }
}
