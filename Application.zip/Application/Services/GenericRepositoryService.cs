﻿using Project_Authentication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Application.Interfaces;
using CVMaker.Models;

namespace Application.Services
{
    public class UserService
    {
        public void setConnnectionString(string connnectionString)
        {

        }
    }
}
 