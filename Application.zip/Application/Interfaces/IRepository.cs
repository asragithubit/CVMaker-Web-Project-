﻿using System.Collections.Generic;


namespace Application.Interfaces
{
    public interface IRepository<TEntity>
    {
        public void setConnnectionString(string connnectionString);
        public  Task Add(TEntity entity, bool includeId = false);
        public  Task Update(TEntity entity, bool includeId = false);
        public  Task DeleteById(int id);
    }
}
