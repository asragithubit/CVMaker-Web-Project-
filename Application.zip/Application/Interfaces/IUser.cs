﻿
using CVMaker.Models;

namespace Application.Interfaces
{
    public interface IUser
    {
        public Task AddPersonalDetails(UserDetails user);
        public Task AddOtherDetails(UserDetails user);
        public Task<int> getId(string cnic);
    }
}
