﻿using System.Collections.Generic;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;


namespace Application.Interfaces
{
    public interface IAdmin<TEntity>
    {
        public void Add(TEntity entity, bool includeId = false);
    }
}
