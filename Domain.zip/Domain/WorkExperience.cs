﻿using CVMaker.Models;
using Project_Authentication.Models;
using System.ComponentModel.DataAnnotations;

namespace CVMaker.Models
{
    public class WorkExperience
    {
        public int Id { get; set; }


        [Required]
        [NumbersValidation(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 })]
        public string JobTitle { get; set; }

        [Required]
        [NumbersValidation(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 })]
        public string WorkPlace { get; set; }

        [Required]
        public string StartDate { get; set; }

        [Required]
        public string EndDate { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        [NumbersValidation(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 })]
        public string Employer { get; set; }
    }
}
