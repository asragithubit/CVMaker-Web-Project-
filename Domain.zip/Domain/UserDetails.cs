﻿using Project_Authentication.Models;
using System.ComponentModel.DataAnnotations;

namespace CVMaker.Models
{
    public class UserDetails
    {

        public int Id { get; set; }

        [Required]
        public string firstName {  get; set; }

        [Required]
        public string lastName { get; set; }

        [Required]
        public string Address {  get; set; }

        [Required]
        public string Nationality { get; set; }


        [Required]
        [StringLength(5,MinimumLength=5,ErrorMessage="Zip Code Should Consist of five digits")]
        public string zipCode { get; set; }

        [Required]
        public string Gender { get; set; }  

        [Required]
        public string City_Town {  get; set; }

        [Required]
        public string dob {  get; set; }

        [Required]
        public string placeOfBirth {  get; set; }
        public string profilePhoto { get; set; }

        [Required]
        [EmailAddress]
        public string email { get; set; }

        [Required]
        [Phone]
        [StringLength(11, MinimumLength = 11, ErrorMessage = "Phone Number Field should be of 11 digits")]
        public string phoneNumber { get; set; }

        [Required]
        [StringLength(15, MinimumLength = 15, ErrorMessage = "CNIC should be of 15 digits i.e 99999-9999999-2")]
        [CnicValidationAttribute(new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '@', '!', '#', '$', '%', '^', '&', '*', ' ', '(', ')', '_', '{', '}', '|' })]

        public string CNIC { get; set; }

        [Required]
        public string Description {  get; set; }


        public List<CourseDetails> Courses { get; set; } = new List<CourseDetails>();
        public List<EducationDetails> educationDetails { get; set; } = new List<EducationDetails>();
        public List<Hobbies> hobbies { get; set; } = new List<Hobbies>();
        public List<LanguageDetails> LanguageDetails { get; set; } = new List<LanguageDetails>();
        public List<Reference> reference { get; set; } = new List<Reference>();
        public List<SkillsDetails> skills { get; set; } = new List<SkillsDetails>();
        public List<WorkExperience> workExperiences { get; set; } = new List<WorkExperience>();
    }
}
