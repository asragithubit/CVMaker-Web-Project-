﻿using System.ComponentModel.DataAnnotations;

namespace CVMaker.Models
{
    public class CnicValidationAttribute : ValidationAttribute
    {
        private readonly char[] notAllowedCharacters;
        public CnicValidationAttribute(char[] _notAllowedCharacters)
        {
            notAllowedCharacters = _notAllowedCharacters;
        }
        protected override ValidationResult? IsValid(object? value,
           ValidationContext validationContext)
        {
            foreach (var character in notAllowedCharacters)
            {
                if (value.ToString().Contains(character))
                {
                    return new ValidationResult("CNIC should not contain alphanumeric characters");
                }
            }

            return ValidationResult.Success;
        }
    }
}
