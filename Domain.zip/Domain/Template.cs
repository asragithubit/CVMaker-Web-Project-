﻿namespace CVMaker.Models
{
    public class Template
    {
        public int? Id { get; set; }
        public string UserId { get; set; }
        public string Resume { get; set; }
    }
}
