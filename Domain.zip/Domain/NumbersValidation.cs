﻿using System.ComponentModel.DataAnnotations;

namespace Project_Authentication.Models
{
    public class NumbersValidation : ValidationAttribute
    {
        private readonly int[] notAllowedNumbers;
        public NumbersValidation(int[] _notAllowedNumbers)
        {
            notAllowedNumbers = _notAllowedNumbers;
        }
        protected override ValidationResult? IsValid(object? value,
           ValidationContext validationContext)
        {
            foreach (var number in notAllowedNumbers)
            {
                if (value.ToString().Contains(number.ToString()))
                {
                    return new ValidationResult("Field does not support numbers");
                }
            }
            return ValidationResult.Success;
        }
    }
}
