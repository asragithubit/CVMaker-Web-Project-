﻿using Project_Authentication.Models;
using System.ComponentModel.DataAnnotations;

namespace CVMaker.Models
{
    public class Reference
    {

        public int Id { get; set; }

        [Required]
        [NumbersValidation(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 })]
        public string CompanyName { get; set; }

        [Required]
        [NumbersValidation(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 })]
        public string ContactPerson { get; set; }

        [Required]
        [EmailAddress]
        public string ContactEmail { get; set; }


        [Required]
        [Phone]
        public string ContactPhoneNumber { get; set; }


    }
}
