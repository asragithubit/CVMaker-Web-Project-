﻿using Project_Authentication.Models;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace CVMaker.Models
{
    public class EducationDetails
    {
        public int Id { get; set; }

        [Required]
        [NumbersValidation(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 })]
        public string Degree { get; set; }

        [Required]
        [NumbersValidation(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 })]
        public string SchoolName { get; set; }

        [Required]
        public string CityTown { get; set; }

        [Required]
        public string StartDate {  get; set; }

        [Required]
        public string EndDate { get; set; }

        [Required]
        public string Description { get; set; }

    }
}
