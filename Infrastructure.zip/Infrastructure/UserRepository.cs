﻿using Microsoft.Data.SqlClient;
using Application.Interfaces;

namespace CVMaker.Models
{
    public class UserRepository : IUser
    {
        private readonly string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;";
        public async Task AddPersonalDetails(UserDetails user)
        {
            string query = "INSERT INTO PersonalInfo (firstName, lastName, Nationality, Address, zipCode, Gender, City_Town, dob, placeOfBirth, profilePhoto, email, phoneNumber, CNIC, Description) " +
                           "VALUES (@fname, @lname, @nationality, @address, @zip, @gender, @city, @dob, @placeOfBirth, @profilePhoto, @email, @phoneNumber, @CNIC, @Description)";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();  // Open the connection asynchronously

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@fname", user.firstName);
                    cmd.Parameters.AddWithValue("@lname", user.lastName);
                    cmd.Parameters.AddWithValue("@nationality", user.Nationality);
                    cmd.Parameters.AddWithValue("@gender", user.Gender);
                    cmd.Parameters.AddWithValue("@zip", user.zipCode);
                    cmd.Parameters.AddWithValue("@address", user.Address);
                    cmd.Parameters.AddWithValue("@city", user.City_Town);
                    cmd.Parameters.AddWithValue("@dob", user.dob);
                    cmd.Parameters.AddWithValue("@placeOfBirth", user.placeOfBirth);
                    cmd.Parameters.AddWithValue("@profilePhoto", (object)user.profilePhoto ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@email", user.email);
                    cmd.Parameters.AddWithValue("@phoneNumber", user.phoneNumber);
                    cmd.Parameters.AddWithValue("@CNIC", user.CNIC);
                    cmd.Parameters.AddWithValue("@Description", user.Description);

                    // Use asynchronous ExecuteNonQuery
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task AddOtherDetails(UserDetails user)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync(); // Open the connection asynchronously

                // Adding Data to CourseDetails
                string CourseQuery = "INSERT INTO CourseDetails (Id, Institution, CourseName, StartDate, EndDate, Description) VALUES (@id, @institute, @course, @startDate, @endDate, @description)";
                foreach (var course in user.Courses)
                {
                    using (SqlCommand courseCmd = new SqlCommand(CourseQuery, connection))
                    {
                        courseCmd.Parameters.AddWithValue("@id", course.Id);
                        courseCmd.Parameters.AddWithValue("@institute", course.Institution);
                        courseCmd.Parameters.AddWithValue("@course", course.CourseName);
                        courseCmd.Parameters.AddWithValue("@startDate", course.StartDate);
                        courseCmd.Parameters.AddWithValue("@endDate", course.EndDate);
                        courseCmd.Parameters.AddWithValue("@description", course.Description);

                        // Use asynchronous ExecuteNonQuery
                        await courseCmd.ExecuteNonQueryAsync();
                    }
                }

                // Repeat the same pattern for EducationDetails, Hobbies, LanguageDetails, References, Skills, and WorkExperience
                // Make sure to use ExecuteNonQueryAsync for all database insertions
            }
        }
        public async Task<int> getId(string cnic)
        {
            string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;";
            string query = "SELECT Id FROM PersonalInfo WHERE CNIC = @cnic";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync(); // Ensure this is asynchronous

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@cnic", cnic);

                    // Use asynchronous ExecuteScalar
                    object result = await cmd.ExecuteScalarAsync();

                    if (result != null)
                    {
                        return Convert.ToInt32(result);
                    }
                    else
                    {
                        throw new Exception("No record found with the provided CNIC.");
                    }
                }
            }
        }
    }
}
