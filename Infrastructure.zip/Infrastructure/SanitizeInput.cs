﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Application.Interfaces;

namespace Infrastructure
{
    public class SanitizeInput:ISanitization
    {
        public string Sanitize(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return input;
            }

            // Simple replacement of <script> and </script> tags
            string sanitizedInput = input.Replace("<script>", "").Replace("</script>", "");

            return sanitizedInput;
        }

    }
}
