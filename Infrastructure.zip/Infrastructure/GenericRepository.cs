﻿using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using System.Diagnostics;
using CVMaker.Models;
using Application.Interfaces;

namespace CVMaker.Infrastructure

{
    public class GenericRepository<TEntity> : IRepository<TEntity>
    {
        private string connectionString;
        public void setConnnectionString(string connnectionString)
        {
            connectionString=connnectionString;
        }
        public GenericRepository(string c)
        {
            this.connectionString = c;
        }
        public GenericRepository() { }
        public async Task Add(TEntity entity, bool includeId = false)
        {
            var tableName = typeof(TEntity).Name;
            var properties = typeof(TEntity).GetProperties();
            if (!includeId)
            {
                properties = properties.Where(p => p.Name != "Id").ToArray();
            }

            var ColumnName = string.Join(",", properties.Select(x => x.Name));
            var parameterNames = string.Join(",", properties.Select(y => "@" + y.Name));

            string query = $"insert into [{tableName}] ({ColumnName}) values({parameterNames})";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);

                foreach (var property in properties)
                {
                    cmd.Parameters.AddWithValue("@" + property.Name, property.GetValue(entity));
                }

                cmd.ExecuteNonQuery();
            }
        }

        public async Task Update(TEntity entity, bool includeId = false)
        {
            var tableName = typeof(TEntity).Name;
            var primaryKey = "Id";
            var properties = typeof(TEntity).GetProperties().Where(x => x.Name != primaryKey);
            var setClause = string.Join(",", properties.Select(a => $"{a.Name}=@{a.Name}"));
            var query = $"Update {tableName} Set {setClause} where {primaryKey}=@{primaryKey}";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);

                foreach (var property in properties)
                {
                    cmd.Parameters.AddWithValue("@" + property.Name, property.GetValue(entity));
                }
                cmd.ExecuteNonQuery();
            }
        }
        public async Task DeleteById(int id)
        {
            var tableName = typeof(TEntity).Name;
            try
            {
                string whereCondition = string.Empty;


                string query = $"DELETE FROM {tableName} where ID= @ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@ID", id);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Exception: {ex.GetType}, Messsage: {ex.Message}");
                Debug.WriteLine($"Exception: {ex.GetType}, Messsage: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }

        }
        public async Task Update(TEntity entity)
        {
            try
            {
                string tableName = typeof(TEntity).Name;
                var properties = typeof(TEntity).GetProperties().Where(p => p.Name != "ID");

                var values = string.Join(",", properties.Select(y => y.Name + " = @" + y.Name));

                string query = $"update {tableName} set {values} where ID= @ID";


                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    foreach (var property in properties)
                    {
                        cmd.Parameters.AddWithValue(property.Name, property.GetValue(entity));
                    }

                    var idProperty = typeof(TEntity).GetProperty("ID");
                    cmd.Parameters.AddWithValue("ID", idProperty.GetValue(entity));

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Exception: {ex.GetType}, Messsage: {ex.Message}");
                Debug.WriteLine($"Exception: {ex.GetType}, Messsage: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }
        }

        public async Task Delete(TEntity entity, bool includeId = false)
        {
            var tableName = typeof(TEntity).Name;
            var primaryKey = "Id";

            string query = $"Delete from {tableName} where {primaryKey}=@{primaryKey}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.ExecuteNonQueryAsync();

            }
        }


        public async Task<List<TEntity>> GetAll<TEntity>(int id) where TEntity : new()
        {
            string tableName = typeof(TEntity).Name;
            string query = $"SELECT * FROM [{tableName}] where id = {id}";

            List<TEntity> list = new List<TEntity>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    TEntity entity = new TEntity();
                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        property.SetValue(entity, dr[property.Name]);
                    }
                    list.Add(entity);
                }
            }
            return list;
        }

        public async Task<List<TEntity>> GetAll<TEntity>() where TEntity : new()
        {
            string tableName = typeof(TEntity).Name;
            string query = $"SELECT * FROM [{tableName}]";

            List<TEntity> list = new List<TEntity>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    TEntity entity = new TEntity();
                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        property.SetValue(entity, dr[property.Name]);
                    }
                    list.Add(entity);
                }
            }
            return list;
        }
        public TEntity GetById(int id)
        {
            string tableName = typeof(TEntity).Name;
            string query = $"SELECT * FROM [{tableName}] WHERE Id = @Id";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Id", id);
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    TEntity entity = Activator.CreateInstance<TEntity>();
                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        property.SetValue(entity, dr[property.Name]);
                    }
                    return entity;
                }
                else
                {
                    return default(TEntity);
                }
            }
        }
        public int getId(string cnic)
        {
            string connectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = CWIZ; Integrated Security = True;";
            string query = "SELECT Id FROM PersonalInfo WHERE CNIC = @cnic";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    // Use parameterized query to prevent SQL injection
                    cmd.Parameters.AddWithValue("@cnic", cnic);

                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        int id = Convert.ToInt32(result);
                        Console.WriteLine(id);
                        return id;
                    }
                    else
                    {
                       
                        throw new Exception("No record found with the provided CNIC.");
                    }
                }
            }


        }
        public void Update(string columnNames, TEntity entity, string compName, string compValue, string tableName)
        {
            try
            {

                var list = columnNames.Split(',');
                var parameterNames = string.Empty;
                for (int i = 0; i < list.Length; i++)
                {
                    if (i == list.Length - 1)
                        parameterNames += (list[i] + " = " + "@" + list[i]);
                    else
                        parameterNames += (list[i] + " = " + "@" + list[i] + " , ");
                }

                string query = $"update {tableName} set {parameterNames} where {compName}= @{compName}";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        if (list.Contains(property.Name))
                        {
                            cmd.Parameters.AddWithValue("@" + property.Name, property.GetValue(entity));
                        }
                    }
                    cmd.Parameters.AddWithValue("@" + compName, compValue);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Exception: {ex.GetType}, Messsage: {ex.Message}");
                Debug.WriteLine($"Exception: {ex.GetType}, Messsage: {ex.Message}");
                throw new Exception("Your Details already exist", ex);
            }

        }

        public void Add(string columnNames, TEntity entity, string tableName, bool includeId=false)
        {
            try
            {
                var properties = typeof(TEntity).GetProperties();

                var list = columnNames.Split(',');
                var parameterNames = string.Empty;
                for (int i = 0; i < list.Length; i++)
                {
                    if (i == list.Length - 1)
                        parameterNames += ("@" + list[i]);
                    else
                        parameterNames += ("@" + list[i] + ",");
                }

                string query = $"insert into {tableName} ({columnNames}) values({parameterNames})";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    foreach (var property in properties)
                    {
                        if (list.Contains(property.Name))
                        {
                            cmd.Parameters.AddWithValue("@" + property.Name, property.GetValue(entity));
                        }
                    }

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Exception: {ex.GetType}, Messsage: {ex.Message}");
                Debug.WriteLine($"Exception: {ex.GetType}, Messsage: {ex.Message}");
                throw new Exception("Your Details already exist", ex);
            }

        }
    }
}
